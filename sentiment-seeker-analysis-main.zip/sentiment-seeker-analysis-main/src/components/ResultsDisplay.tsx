
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Smile, Frown, Meh, TrendingUp, BarChart3, FileText, Lightbulb } from 'lucide-react';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Cell } from 'recharts';

const ResultsDisplay = ({ results, originalText }) => {
  if (!results || results.length === 0) return null;

  const primaryResult = results[0];
  const sentiment = primaryResult.label;
  const confidence = (primaryResult.score * 100).toFixed(1);
  const confidenceNum = parseFloat(confidence);

  // Create chart data for sentiment visualization
  const chartData = results.map(result => ({
    sentiment: result.label,
    confidence: parseFloat((result.score * 100).toFixed(1))
  }));

  // Add neutral if not present
  if (!results.find(r => r.label === 'NEUTRAL')) {
    const totalConfidence = results.reduce((sum, r) => sum + r.score, 0);
    const neutralConfidence = Math.max(0, (1 - totalConfidence) * 100);
    if (neutralConfidence > 0) {
      chartData.push({
        sentiment: 'NEUTRAL',
        confidence: parseFloat(neutralConfidence.toFixed(1))
      });
    }
  }

  // Function to detect and make links clickable
  const renderTextWithLinks = (text) => {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const parts = text.split(urlRegex);
    
    return parts.map((part, index) => {
      if (urlRegex.test(part)) {
        return (
          <a
            key={index}
            href={part}
            target="_blank"
            rel="noopener noreferrer"
            className="text-blue-400 hover:text-blue-300 underline"
          >
            {part}
          </a>
        );
      }
      return part;
    });
  };

  // Simple AI summarization (keyword-based fallback)
  const generateSummary = (text) => {
    const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
    if (sentences.length <= 2) return text;
    
    // Take first and last sentences for a simple summary
    const summary = sentences.length > 3 
      ? `${sentences[0].trim()}. ${sentences[sentences.length - 1].trim()}.`
      : sentences.slice(0, 2).join('. ') + '.';
    
    return summary;
  };

  // Generate suggestions based on sentiment analysis
  const generateSuggestions = () => {
    const suggestions = [];
    
    if (sentiment === 'POSITIVE') {
      if (confidenceNum > 80) {
        suggestions.push("This content expresses strong positive sentiment - consider using it for marketing or testimonials.");
        suggestions.push("Share this positive feedback to boost team morale or customer confidence.");
      } else {
        suggestions.push("The positive sentiment is moderate - consider enhancing the emotional language for stronger impact.");
      }
    } else if (sentiment === 'NEGATIVE') {
      if (confidenceNum > 80) {
        suggestions.push("Strong negative sentiment detected - immediate attention may be required to address concerns.");
        suggestions.push("Consider implementing damage control strategies or customer service follow-up.");
        suggestions.push("Analyze the specific complaints to identify improvement opportunities.");
      } else {
        suggestions.push("Moderate negative sentiment - monitor for patterns and consider proactive communication.");
      }
    } else {
      suggestions.push("Neutral sentiment suggests factual or balanced content - good for informational purposes.");
      suggestions.push("Consider adding emotional elements if you want to increase engagement.");
    }

    // Confidence-based suggestions
    if (confidenceNum < 60) {
      suggestions.push("Low confidence score suggests mixed emotions - consider segmenting the text for more targeted analysis.");
    }

    return suggestions;
  };

  const getBarColor = (sentimentLabel) => {
    switch (sentimentLabel) {
      case 'POSITIVE':
        return '#10b981';
      case 'NEGATIVE':
        return '#ef4444';
      default:
        return '#8b5cf6';
    }
  };

  const getSentimentIcon = () => {
    switch (sentiment) {
      case 'POSITIVE':
        return <Smile className="w-6 h-6 text-green-400" />;
      case 'NEGATIVE':
        return <Frown className="w-6 h-6 text-red-400" />;
      default:
        return <Meh className="w-6 h-6 text-gray-400" />;
    }
  };

  const getSentimentColor = () => {
    switch (sentiment) {
      case 'POSITIVE':
        return 'from-green-500 to-emerald-500';
      case 'NEGATIVE':
        return 'from-red-500 to-pink-500';
      default:
        return 'from-purple-500 to-indigo-500';
    }
  };

  const getSentimentText = () => {
    switch (sentiment) {
      case 'POSITIVE':
        return 'Positive sentiment detected! This text expresses favorable emotions or opinions.';
      case 'NEGATIVE':
        return 'Negative sentiment detected. This text expresses unfavorable emotions or opinions.';
      default:
        return 'Neutral sentiment detected. This text is relatively balanced or factual.';
    }
  };

  const chartConfig = {
    confidence: {
      label: "Confidence",
    },
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/10 backdrop-blur-lg border-white/20 animate-in slide-in-from-bottom duration-500">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <TrendingUp className="w-5 h-5 mr-2" />
            Analysis Results
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Primary Result */}
          <div className="text-center space-y-4">
            <div className="flex items-center justify-center space-x-3">
              {getSentimentIcon()}
              <Badge className={`bg-gradient-to-r ${getSentimentColor()} text-white text-lg px-4 py-2`}>
                {sentiment}
              </Badge>
            </div>
            
            <div className="space-y-2">
              <p className="text-gray-300">{getSentimentText()}</p>
            </div>
          </div>

          {/* Confidence Score */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-gray-300 font-medium">Confidence Score</span>
              <span className="text-white font-bold text-lg">{confidence}%</span>
            </div>
            
            <Progress 
              value={confidenceNum} 
              className="h-3 bg-white/20"
            />
            
            <div className="flex justify-between text-sm text-gray-400">
              <span>Low Confidence</span>
              <span>High Confidence</span>
            </div>
          </div>

          {/* Interpretation */}
          <div className="bg-white/5 rounded-lg p-4 border border-white/10">
            <h4 className="text-white font-semibold mb-2">Interpretation</h4>
            <p className="text-gray-300 text-sm">
              {confidenceNum > 80 ? 
                "The model is very confident in this sentiment classification." :
                confidenceNum > 60 ?
                "The model is moderately confident in this sentiment classification." :
                "The model has low confidence - the text may contain mixed sentiments or be ambiguous."
              }
            </p>
          </div>

          {/* All Results (if multiple) */}
          {results.length > 1 && (
            <div className="space-y-2">
              <h4 className="text-white font-semibold">All Predictions</h4>
              {results.map((result, index) => (
                <div key={index} className="flex items-center justify-between text-sm">
                  <span className="text-gray-300">{result.label}</span>
                  <span className="text-white">{(result.score * 100).toFixed(1)}%</span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Bar Chart */}
      <Card className="bg-white/10 backdrop-blur-lg border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            Sentiment Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <XAxis 
                  dataKey="sentiment" 
                  tick={{ fill: '#d1d5db', fontSize: 12 }}
                  axisLine={{ stroke: '#374151' }}
                />
                <YAxis 
                  tick={{ fill: '#d1d5db', fontSize: 12 }}
                  axisLine={{ stroke: '#374151' }}
                  label={{ value: 'Confidence %', angle: -90, position: 'insideLeft', style: { textAnchor: 'middle', fill: '#d1d5db' } }}
                />
                <ChartTooltip 
                  content={<ChartTooltipContent />}
                  cursor={{ fill: 'rgba(255, 255, 255, 0.1)' }}
                />
                <Bar 
                  dataKey="confidence" 
                  radius={[4, 4, 0, 0]}
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={getBarColor(entry.sentiment)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* AI-Generated Suggestions */}
      <Card className="bg-white/10 backdrop-blur-lg border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Lightbulb className="w-5 h-5 mr-2" />
            AI Recommendations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {generateSuggestions().map((suggestion, index) => (
              <div key={index} className="bg-white/5 rounded-lg p-3 border border-white/10">
                <p className="text-gray-300 text-sm leading-relaxed">
                  {suggestion}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* AI Summary */}
      {originalText && (
        <Card className="bg-white/10 backdrop-blur-lg border-white/20">
          <CardHeader>
            <CardTitle className="text-white flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              AI Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                <p className="text-gray-300 text-sm leading-relaxed">
                  {renderTextWithLinks(generateSummary(originalText))}
                </p>
              </div>
              <p className="text-gray-400 text-xs">
                Summary generated using keyword extraction and sentence ranking
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default ResultsDisplay;

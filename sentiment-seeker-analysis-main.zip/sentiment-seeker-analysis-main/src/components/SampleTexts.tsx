
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Smile, Frown, Meh, Lightbulb } from 'lucide-react';

const SampleTexts = ({ onSampleSelect }) => {
  const samples = [
    {
      category: 'Positive',
      icon: <Smile className="w-4 h-4" />,
      color: 'from-green-500 to-emerald-500',
      texts: [
        "I absolutely love this new restaurant! The food was incredible and the service was outstanding.",
        "This is the best day ever! Everything is going perfectly and I couldn't be happier.",
        "Amazing product quality! Exceeded all my expectations and delivered exactly what was promised."
      ]
    },
    {
      category: 'Negative',
      icon: <Frown className="w-4 h-4" />,
      color: 'from-red-500 to-pink-500',
      texts: [
        "This is absolutely terrible. I hate everything about this experience and want my money back.",
        "Worst customer service ever! They were rude, unhelpful, and completely ignored my concerns.",
        "I'm so disappointed and frustrated. This product is completely broken and useless."
      ]
    },
    {
      category: 'Neutral',
      icon: <Meh className="w-4 h-4" />,
      color: 'from-gray-500 to-slate-500',
      texts: [
        "The weather is okay today. It's not particularly good or bad, just average conditions.",
        "I went to the store and bought some groceries. It was a normal shopping experience.",
        "The meeting was informative. We covered the agenda items and discussed next steps."
      ]
    }
  ];

  return (
    <Card className="bg-white/10 backdrop-blur-lg border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Lightbulb className="w-5 h-5 mr-2" />
          Try Sample Texts
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid md:grid-cols-3 gap-6">
          {samples.map((sample) => (
            <div key={sample.category} className="space-y-3">
              <div className={`flex items-center justify-center py-2 px-4 rounded-lg bg-gradient-to-r ${sample.color} text-white font-semibold`}>
                {sample.icon}
                <span className="ml-2">{sample.category}</span>
              </div>
              
              <div className="space-y-2">
                {sample.texts.map((text, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    className="w-full text-left text-sm text-gray-300 hover:text-white hover:bg-white/10 p-3 h-auto whitespace-normal"
                    onClick={() => onSampleSelect(text)}
                  >
                    "{text}"
                  </Button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default SampleTexts;


import { useRef, useImperativeHandle, forwardRef } from 'react';

const SentimentAnalyzer = forwardRef((props, ref) => {
  const pipelineRef = useRef(null);
  const isLoadingRef = useRef(false);

  const loadPipeline = async () => {
    if (pipelineRef.current || isLoadingRef.current) {
      return pipelineRef.current;
    }

    isLoadingRef.current = true;
    
    try {
      // Dynamic import to avoid build issues
      const { pipeline } = await import('@huggingface/transformers');
      
      console.log('Loading sentiment analysis model...');
      
      // Use a lightweight sentiment model
      pipelineRef.current = await pipeline(
        'sentiment-analysis',
        'Xenova/distilbert-base-uncased-finetuned-sst-2-english'
      );
      
      console.log('Model loaded successfully!');
      return pipelineRef.current;
    } catch (error) {
      console.error('Failed to load sentiment model:', error);
      // Fallback to mock analysis
      return null;
    } finally {
      isLoadingRef.current = false;
    }
  };

  const mockAnalysis = (text) => {
    // Simple keyword-based fallback
    const positiveWords = ['love', 'great', 'amazing', 'wonderful', 'excellent', 'fantastic', 'awesome', 'good', 'happy', 'perfect'];
    const negativeWords = ['hate', 'terrible', 'awful', 'horrible', 'bad', 'worst', 'sad', 'angry', 'disgusting', 'disappointing'];
    
    const words = text.toLowerCase().split(/\s+/);
    let positiveCount = 0;
    let negativeCount = 0;
    
    words.forEach(word => {
      if (positiveWords.some(pos => word.includes(pos))) positiveCount++;
      if (negativeWords.some(neg => word.includes(neg))) negativeCount++;
    });
    
    if (positiveCount > negativeCount) {
      return [{ label: 'POSITIVE', score: Math.min(0.7 + (positiveCount * 0.1), 0.95) }];
    } else if (negativeCount > positiveCount) {
      return [{ label: 'NEGATIVE', score: Math.min(0.7 + (negativeCount * 0.1), 0.95) }];
    } else {
      return [{ label: 'NEUTRAL', score: 0.6 }];
    }
  };

  const analyze = async (text) => {
    if (!text.trim()) {
      throw new Error('Please enter some text to analyze');
    }

    try {
      const pipeline = await loadPipeline();
      
      if (pipeline) {
        console.log('Analyzing with ML model:', text);
        const result = await pipeline(text);
        console.log('ML Analysis result:', result);
        return result;
      } else {
        console.log('Using fallback analysis for:', text);
        const result = mockAnalysis(text);
        console.log('Fallback analysis result:', result);
        return result;
      }
    } catch (error) {
      console.error('Analysis error:', error);
      // Use fallback on any error
      return mockAnalysis(text);
    }
  };

  useImperativeHandle(ref, () => ({
    analyze
  }));

  return null; // This is a headless component
});

SentimentAnalyzer.displayName = 'SentimentAnalyzer';

export default SentimentAnalyzer;


import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Smile } from 'lucide-react';

const EmojiTable = ({ onEmojiSelect }) => {
  const emojiData = [
    { emoji: '😊', text: 'I am feeling great today!', sentiment: 'Positive' },
    { emoji: '🎉', text: 'Congratulations on your success!', sentiment: 'Positive' },
    { emoji: '😢', text: 'I am really sad about what happened.', sentiment: 'Negative' },
    { emoji: '😡', text: 'This is terrible and makes me angry!', sentiment: 'Negative' },
    { emoji: '😐', text: 'The weather is okay today.', sentiment: 'Neutral' },
    { emoji: '🤔', text: 'I need to think about this more.', sentiment: 'Neutral' },
    { emoji: '⚖️', text: 'The situation has both pros and cons.', sentiment: 'Neutral' },
  ];

  return (
    <Card className="bg-white/10 backdrop-blur-lg border-white/20">
      <CardHeader>
        <CardTitle className="text-white flex items-center">
          <Smile className="w-5 h-5 mr-2" />
          Quick Test with Emojis
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow className="border-white/20 hover:bg-white/5">
              <TableHead className="text-gray-300 font-semibold">Emoji</TableHead>
              <TableHead className="text-gray-300 font-semibold">Sample Text</TableHead>
              <TableHead className="text-gray-300 font-semibold">Expected</TableHead>
              <TableHead className="text-gray-300 font-semibold">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {emojiData.map((item, index) => (
              <TableRow key={index} className="border-white/10 hover:bg-white/5">
                <TableCell className="text-2xl">{item.emoji}</TableCell>
                <TableCell className="text-gray-300 text-sm max-w-xs">
                  {item.text}
                </TableCell>
                <TableCell>
                  <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                    item.sentiment === 'Positive' ? 'bg-green-500/20 text-green-300' :
                    item.sentiment === 'Negative' ? 'bg-red-500/20 text-red-300' :
                    'bg-gray-500/20 text-gray-300'
                  }`}>
                    {item.sentiment}
                  </span>
                </TableCell>
                <TableCell>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => onEmojiSelect(item.text)}
                    className="text-purple-300 hover:text-white hover:bg-purple-600/20"
                  >
                    Try it
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default EmojiTable;

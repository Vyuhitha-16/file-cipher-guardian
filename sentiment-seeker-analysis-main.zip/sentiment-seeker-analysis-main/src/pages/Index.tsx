
import { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Heart, Meh, Sparkles } from 'lucide-react';
import SentimentAnalyzer from '@/components/SentimentAnalyzer';
import EmojiTable from '@/components/EmojiTable';
import ResultsDisplay from '@/components/ResultsDisplay';

const Index = () => {
  const [text, setText] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [results, setResults] = useState(null);
  const [analyzedText, setAnalyzedText] = useState('');
  const analyzerRef = useRef(null);

  const handleAnalyze = async () => {
    if (!text.trim() || !analyzerRef.current) return;
    
    setIsAnalyzing(true);
    try {
      const sentiment = await analyzerRef.current.analyze(text);
      setResults(sentiment);
      setAnalyzedText(text);
    } catch (error) {
      console.error('Analysis failed:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleEmojiSelect = (emojiText) => {
    setText(emojiText);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      {/* Background Animation */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-blue-600/20 animate-pulse"></div>
      
      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Sparkles className="w-8 h-8 text-purple-400 mr-3" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Sentiment Analysis
            </h1>
            <Heart className="w-8 h-8 text-pink-400 ml-3" />
          </div>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto">
            Discover the emotional tone of any text using advanced machine learning. Analyze sentiment with confidence scores and visual feedback.
          </p>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          {/* Input Section */}
          <Card className="bg-white/10 backdrop-blur-lg border-white/20">
            <CardHeader>
              <CardTitle className="text-white flex items-center">
                <Meh className="w-5 h-5 mr-2" />
                Enter Text to Analyze
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Type or paste your text here... (e.g., 'I love this new product!', 'This is terrible', 'Check out https://example.com for more info')"
                value={text}
                onChange={(e) => setText(e.target.value)}
                className="min-h-32 bg-white/10 border-white/20 text-white placeholder-gray-400 focus:border-purple-400 transition-colors"
                maxLength={1000}
              />
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-400">
                  {text.length}/1000 characters
                </span>
                <Button
                  onClick={handleAnalyze}
                  disabled={!text.trim() || isAnalyzing}
                  className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold px-8"
                >
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Analyzing...
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 mr-2" />
                      Analyze Sentiment
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Emoji Table */}
          <EmojiTable onEmojiSelect={handleEmojiSelect} />

          {/* Results */}
          {results && <ResultsDisplay results={results} originalText={analyzedText} />}

          {/* Info Card */}
          <Card className="bg-white/5 backdrop-blur-lg border-white/10">
            <CardContent className="pt-6">
              <div className="text-center text-gray-300">
                <h3 className="text-lg font-semibold mb-2">How it works</h3>
                <p className="text-sm">
                  This tool uses advanced machine learning models to analyze the emotional content of text.
                  It provides confidence scores, visual charts, clickable links, and intelligent summaries.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Hidden Sentiment Analyzer Component */}
      <SentimentAnalyzer ref={analyzerRef} />
    </div>
  );
};

export default Index;


# Sentiment Analysis App

## Project Description

A modern web application for analyzing the emotional tone of text using advanced machine learning models. Built with React, TypeScript, and Tailwind CSS.

## Features

- Real-time sentiment analysis with confidence scores
- Interactive emoji table for quick testing
- Visual charts and feedback
- Support for clickable links in text
- Responsive design with modern UI

## Technologies Used

This project is built with:

- Vite
- TypeScript
- React
- shadcn-ui
- Tailwind CSS
- Hugging Face Transformers

## Getting Started

### Prerequisites

Make sure you have Node.js & npm installed - [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating)

### Installation

Follow these steps to run the project locally:

```sh
# Step 1: Clone the repository
git clone <YOUR_GIT_URL>

# Step 2: Navigate to the project directory
cd <YOUR_PROJECT_NAME>

# Step 3: Install the necessary dependencies
npm install

# Step 4: Start the development server
npm run dev
```

## Usage

1. Enter text in the input area
2. Click "Analyze Sentiment" to get results
3. View confidence scores and visual feedback
4. Use the emoji table for quick sentiment testing
5. Links in the text will be automatically clickable

## How It Works

This application uses advanced machine learning models to analyze the emotional content of text. It provides:

- Confidence scores for sentiment predictions
- Visual charts for better understanding
- Fallback analysis for offline functionality
- Interactive features for enhanced user experience

## Contributing

Feel free to submit issues and enhancement requests!

## License

This project is open source and available under the [MIT License](LICENSE).
